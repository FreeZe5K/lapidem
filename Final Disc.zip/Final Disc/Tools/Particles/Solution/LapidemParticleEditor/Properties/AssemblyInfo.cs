﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("LapidemParticle Editor")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Lapidem")]
[assembly: AssemblyProduct("Lapidem Particle Editor")]
[assembly: AssemblyCopyright("Copyright © Lapidem 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]